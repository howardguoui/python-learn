# Welcome to Quantum Algorithms

Started at https://github.com/TheAlgorithms/Python/issues/1831

* D-Wave: https://www.dwavesys.com and https://github.com/dwavesystems
* Google: https://research.google/teams/applied-science/quantum
* IBM: https://qiskit.org and https://github.com/Qiskit
* Rigetti: https://rigetti.com and https://github.com/rigetti
